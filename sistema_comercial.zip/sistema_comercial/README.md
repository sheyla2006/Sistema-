# Sistema Comercial – Flask + Flask-Login + Werkzeug + MySQL/PostgreSQL

Proyecto integrador – Desarrollo de Aplicaciones Web (Unidad 4, Semana 14).

## Funcionalidades
- **Login**: registro, hash de contraseñas (Werkzeug), inicio y cierre de sesión (Flask-Login), protección con `@login_required`, CSRF en todos los formularios.
- **CRUD completo**: categorías, proveedores, clientes, productos y facturas.
- **7 tablas relacionadas**: usuarios, categorias, proveedores, productos, clientes, facturas, detalle_factura.
- **Facturación**: varias líneas por factura, control de stock, IVA, anulación (devuelve stock).

## Modelo relacional
```
categorias 1──* productos *──1 proveedores
clientes   1──* facturas  *──1 usuarios
facturas   1──* detalle_factura *──1 productos
```

## Instalación
```bash
python -m venv venv
venv\Scripts\activate          # Windows   (Linux/Mac: source venv/bin/activate)
pip install -r requirements.txt
copy .env.example .env         # Linux/Mac: cp .env.example .env
```
1. Cree la base de datos vacía `sistema_comercial` (MySQL o PostgreSQL) y ajuste `DATABASE_URL` en `.env`.
   - MySQL: puede ejecutar `schema.sql`, o dejar que la app cree las tablas sola.
   - PostgreSQL: use la línea comentada del `.env.example`.
2. (Opcional) Cargar datos de ejemplo: `python seed.py` → usuario `admin@demo.com` / `Admin123`.
3. Ejecutar: `python app.py` y abrir http://127.0.0.1:5000

## Pruebas automáticas
```bash
python -m unittest tests -v
```

## Lista de pruebas manuales
| # | Prueba | Resultado esperado |
|---|--------|--------------------|
| 1 | Abrir `/productos` sin iniciar sesión | Redirige a `/login` |
| 2 | Registrar usuario con clave de 3 letras | Muestra error de validación |
| 3 | Registrar usuario válido y revisar la tabla `usuarios` | `password_hash` empieza con `scrypt:` o `pbkdf2:` |
| 4 | Iniciar sesión con clave incorrecta | «Correo o contraseña incorrectos» |
| 5 | Crear, editar y eliminar una categoría | Mensajes de confirmación |
| 6 | Eliminar categoría/proveedor/cliente con registros asociados | Se bloquea con mensaje |
| 7 | Crear producto con código repetido | «Ya existe un producto con ese código» |
| 8 | Facturar más unidades que el stock | Se rechaza y no cambia el stock |
| 9 | Emitir factura válida | Stock disminuye, total = subtotal + IVA |
| 10 | Anular factura | Stock se devuelve |
| 11 | Cerrar sesión y presionar «atrás» | No permite entrar a páginas internas |
