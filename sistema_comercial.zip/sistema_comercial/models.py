from datetime import datetime
from decimal import Decimal

from flask_login import UserMixin
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash, generate_password_hash

db = SQLAlchemy()


class Usuario(UserMixin, db.Model):
    __tablename__ = "usuarios"

    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    creado_en = db.Column(db.DateTime, default=datetime.now)

    facturas = db.relationship("Factura", back_populates="usuario")

    def set_password(self, password):
        # Werkzeug genera el hash con sal; nunca se guarda la contraseña en claro
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Categoria(db.Model):
    __tablename__ = "categorias"

    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(80), unique=True, nullable=False)
    descripcion = db.Column(db.String(255))

    productos = db.relationship("Producto", back_populates="categoria")


class Proveedor(db.Model):
    __tablename__ = "proveedores"

    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(120), nullable=False)
    ruc = db.Column(db.String(13), unique=True, nullable=False)
    telefono = db.Column(db.String(20))
    email = db.Column(db.String(120))
    direccion = db.Column(db.String(200))

    productos = db.relationship("Producto", back_populates="proveedor")


class Producto(db.Model):
    __tablename__ = "productos"

    id = db.Column(db.Integer, primary_key=True)
    codigo = db.Column(db.String(30), unique=True, nullable=False)
    nombre = db.Column(db.String(120), nullable=False)
    descripcion = db.Column(db.String(255))
    precio = db.Column(db.Numeric(10, 2), nullable=False)
    stock = db.Column(db.Integer, nullable=False, default=0)
    categoria_id = db.Column(db.Integer, db.ForeignKey("categorias.id"), nullable=False)
    proveedor_id = db.Column(db.Integer, db.ForeignKey("proveedores.id"), nullable=False)

    categoria = db.relationship("Categoria", back_populates="productos")
    proveedor = db.relationship("Proveedor", back_populates="productos")
    detalles = db.relationship("DetalleFactura", back_populates="producto")


class Cliente(db.Model):
    __tablename__ = "clientes"

    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(120), nullable=False)
    cedula = db.Column(db.String(13), unique=True, nullable=False)
    telefono = db.Column(db.String(20))
    email = db.Column(db.String(120))
    direccion = db.Column(db.String(200))

    facturas = db.relationship("Factura", back_populates="cliente")


class Factura(db.Model):
    __tablename__ = "facturas"

    id = db.Column(db.Integer, primary_key=True)
    numero = db.Column(db.String(20), unique=True, nullable=False)
    fecha = db.Column(db.DateTime, default=datetime.now, nullable=False)
    estado = db.Column(db.String(10), nullable=False, default="emitida")  # emitida | pagada | anulada
    observaciones = db.Column(db.String(255))
    subtotal = db.Column(db.Numeric(10, 2), nullable=False, default=Decimal("0"))
    iva = db.Column(db.Numeric(10, 2), nullable=False, default=Decimal("0"))
    total = db.Column(db.Numeric(10, 2), nullable=False, default=Decimal("0"))
    cliente_id = db.Column(db.Integer, db.ForeignKey("clientes.id"), nullable=False)
    usuario_id = db.Column(db.Integer, db.ForeignKey("usuarios.id"), nullable=False)

    cliente = db.relationship("Cliente", back_populates="facturas")
    usuario = db.relationship("Usuario", back_populates="facturas")
    detalles = db.relationship(
        "DetalleFactura", back_populates="factura", cascade="all, delete-orphan"
    )


class DetalleFactura(db.Model):
    __tablename__ = "detalle_factura"

    id = db.Column(db.Integer, primary_key=True)
    factura_id = db.Column(db.Integer, db.ForeignKey("facturas.id"), nullable=False)
    producto_id = db.Column(db.Integer, db.ForeignKey("productos.id"), nullable=False)
    cantidad = db.Column(db.Integer, nullable=False)
    precio_unitario = db.Column(db.Numeric(10, 2), nullable=False)

    factura = db.relationship("Factura", back_populates="detalles")
    producto = db.relationship("Producto", back_populates="detalles")

    @property
    def subtotal(self):
        return self.precio_unitario * self.cantidad
