from decimal import Decimal, InvalidOperation
from urllib.parse import urljoin, urlparse
from uuid import uuid4

from flask import Flask, flash, redirect, render_template, request, url_for
from flask_login import (LoginManager, current_user, login_required,
                         login_user, logout_user)
from flask_wtf.csrf import CSRFProtect
from sqlalchemy import func
from sqlalchemy.exc import IntegrityError

from config import Config
from models import (Categoria, Cliente, DetalleFactura, Factura, Producto,
                    Proveedor, Usuario, db)

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)
CSRFProtect(app)

login_manager = LoginManager(app)
login_manager.login_view = "login"
login_manager.login_message = "Debe iniciar sesión para acceder a esta página."
login_manager.login_message_category = "warning"


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(Usuario, int(user_id))


# ----------------------------------------------------------------- utilidades
def url_segura(destino):
    """Evita redirecciones a sitios externos desde el parámetro ?next="""
    if not destino:
        return False
    base = urlparse(request.host_url)
    final = urlparse(urljoin(request.host_url, destino))
    return final.scheme in ("http", "https") and base.netloc == final.netloc


def a_decimal(valor):
    try:
        return Decimal(str(valor).replace(",", ".").strip())
    except (InvalidOperation, ValueError):
        return None


def a_entero(valor):
    try:
        return int(str(valor).strip())
    except (ValueError, TypeError):
        return None


def guardar(mensaje_ok, mensaje_duplicado):
    """Confirma la transacción y devuelve True si todo salió bien."""
    try:
        db.session.commit()
        flash(mensaje_ok, "success")
        return True
    except IntegrityError:
        db.session.rollback()
        flash(mensaje_duplicado, "danger")
        return False


# ------------------------------------------------------------- autenticación
@app.route("/")
def index():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/registro", methods=["GET", "POST"])
def registro():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        nombre = request.form.get("nombre", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirmar = request.form.get("confirmar", "")

        errores = []
        if len(nombre) < 3:
            errores.append("El nombre debe tener al menos 3 caracteres.")
        if "@" not in email or "." not in email:
            errores.append("Ingrese un correo electrónico válido.")
        if len(password) < 6:
            errores.append("La contraseña debe tener al menos 6 caracteres.")
        if password != confirmar:
            errores.append("Las contraseñas no coinciden.")
        if Usuario.query.filter_by(email=email).first():
            errores.append("Ya existe un usuario registrado con ese correo.")

        if errores:
            for e in errores:
                flash(e, "danger")
            return render_template("registro.html", nombre=nombre, email=email)

        usuario = Usuario(nombre=nombre, email=email)
        usuario.set_password(password)  # se almacena solo el hash
        db.session.add(usuario)
        db.session.commit()
        flash("Cuenta creada correctamente. Ya puede iniciar sesión.", "success")
        return redirect(url_for("login"))

    return render_template("registro.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        recordar = bool(request.form.get("recordar"))

        usuario = Usuario.query.filter_by(email=email).first()
        if usuario and usuario.check_password(password):
            login_user(usuario, remember=recordar)
            flash(f"Bienvenido, {usuario.nombre}.", "success")
            siguiente = request.args.get("next")
            return redirect(siguiente if url_segura(siguiente) else url_for("dashboard"))

        flash("Correo o contraseña incorrectos.", "danger")
        return render_template("login.html", email=email)

    return render_template("login.html")


@app.route("/logout", methods=["POST"])
@login_required
def logout():
    logout_user()
    flash("Sesión cerrada correctamente.", "info")
    return redirect(url_for("login"))


# ----------------------------------------------------------------- dashboard
@app.route("/dashboard")
@login_required
def dashboard():
    ventas = (
        db.session.query(func.coalesce(func.sum(Factura.total), 0))
        .filter(Factura.estado != "anulada")
        .scalar()
    )
    contadores = {
        "productos": Producto.query.count(),
        "clientes": Cliente.query.count(),
        "proveedores": Proveedor.query.count(),
        "facturas": Factura.query.count(),
    }
    stock_bajo = Producto.query.filter(Producto.stock <= 5).order_by(Producto.stock).limit(8).all()
    recientes = Factura.query.order_by(Factura.fecha.desc()).limit(5).all()
    return render_template("dashboard.html", contadores=contadores, ventas=ventas,
                           stock_bajo=stock_bajo, recientes=recientes)


# ---------------------------------------------------------------- categorías
@app.route("/categorias")
@login_required
def categorias():
    return render_template("categorias/lista.html",
                           categorias=Categoria.query.order_by(Categoria.nombre).all())


@app.route("/categorias/nueva", methods=["GET", "POST"])
@login_required
def categoria_nueva():
    if request.method == "POST":
        nombre = request.form.get("nombre", "").strip()
        if not nombre:
            flash("El nombre es obligatorio.", "danger")
        else:
            db.session.add(Categoria(nombre=nombre,
                                     descripcion=request.form.get("descripcion", "").strip()))
            if guardar("Categoría creada.", "Ya existe una categoría con ese nombre."):
                return redirect(url_for("categorias"))
    return render_template("categorias/form.html", categoria=None)


@app.route("/categorias/<int:id>/editar", methods=["GET", "POST"])
@login_required
def categoria_editar(id):
    categoria = db.get_or_404(Categoria, id)
    if request.method == "POST":
        nombre = request.form.get("nombre", "").strip()
        if not nombre:
            flash("El nombre es obligatorio.", "danger")
        else:
            categoria.nombre = nombre
            categoria.descripcion = request.form.get("descripcion", "").strip()
            if guardar("Categoría actualizada.", "Ya existe una categoría con ese nombre."):
                return redirect(url_for("categorias"))
    return render_template("categorias/form.html", categoria=categoria)


@app.route("/categorias/<int:id>/eliminar", methods=["POST"])
@login_required
def categoria_eliminar(id):
    categoria = db.get_or_404(Categoria, id)
    if categoria.productos:
        flash("No se puede eliminar: la categoría tiene productos asociados.", "danger")
    else:
        db.session.delete(categoria)
        guardar("Categoría eliminada.", "No se pudo eliminar la categoría.")
    return redirect(url_for("categorias"))


# --------------------------------------------------------------- proveedores
def leer_datos_persona(obj, campo_id):
    """Lee los campos comunes de clientes y proveedores. Devuelve lista de errores."""
    obj.nombre = request.form.get("nombre", "").strip()
    setattr(obj, campo_id, request.form.get(campo_id, "").strip())
    obj.telefono = request.form.get("telefono", "").strip()
    obj.email = request.form.get("email", "").strip().lower()
    obj.direccion = request.form.get("direccion", "").strip()
    errores = []
    if not obj.nombre:
        errores.append("El nombre es obligatorio.")
    if not getattr(obj, campo_id).isdigit() or len(getattr(obj, campo_id)) not in (10, 13):
        errores.append("El documento debe tener 10 dígitos (cédula) o 13 (RUC), solo números.")
    return errores


@app.route("/proveedores")
@login_required
def proveedores():
    return render_template("proveedores/lista.html",
                           proveedores=Proveedor.query.order_by(Proveedor.nombre).all())


@app.route("/proveedores/nuevo", methods=["GET", "POST"])
@login_required
def proveedor_nuevo():
    proveedor = Proveedor()
    if request.method == "POST":
        errores = leer_datos_persona(proveedor, "ruc")
        if errores:
            for e in errores:
                flash(e, "danger")
        else:
            db.session.add(proveedor)
            if guardar("Proveedor creado.", "Ya existe un proveedor con ese RUC."):
                return redirect(url_for("proveedores"))
    return render_template("proveedores/form.html", proveedor=proveedor, editando=False)


@app.route("/proveedores/<int:id>/editar", methods=["GET", "POST"])
@login_required
def proveedor_editar(id):
    proveedor = db.get_or_404(Proveedor, id)
    if request.method == "POST":
        errores = leer_datos_persona(proveedor, "ruc")
        if errores:
            for e in errores:
                flash(e, "danger")
            db.session.rollback()
        elif guardar("Proveedor actualizado.", "Ya existe un proveedor con ese RUC."):
            return redirect(url_for("proveedores"))
    return render_template("proveedores/form.html", proveedor=proveedor, editando=True)


@app.route("/proveedores/<int:id>/eliminar", methods=["POST"])
@login_required
def proveedor_eliminar(id):
    proveedor = db.get_or_404(Proveedor, id)
    if proveedor.productos:
        flash("No se puede eliminar: el proveedor tiene productos asociados.", "danger")
    else:
        db.session.delete(proveedor)
        guardar("Proveedor eliminado.", "No se pudo eliminar el proveedor.")
    return redirect(url_for("proveedores"))


# ------------------------------------------------------------------ clientes
@app.route("/clientes")
@login_required
def clientes():
    return render_template("clientes/lista.html",
                           clientes=Cliente.query.order_by(Cliente.nombre).all())


@app.route("/clientes/nuevo", methods=["GET", "POST"])
@login_required
def cliente_nuevo():
    cliente = Cliente()
    if request.method == "POST":
        errores = leer_datos_persona(cliente, "cedula")
        if errores:
            for e in errores:
                flash(e, "danger")
        else:
            db.session.add(cliente)
            if guardar("Cliente creado.", "Ya existe un cliente con esa cédula/RUC."):
                return redirect(url_for("clientes"))
    return render_template("clientes/form.html", cliente=cliente, editando=False)


@app.route("/clientes/<int:id>/editar", methods=["GET", "POST"])
@login_required
def cliente_editar(id):
    cliente = db.get_or_404(Cliente, id)
    if request.method == "POST":
        errores = leer_datos_persona(cliente, "cedula")
        if errores:
            for e in errores:
                flash(e, "danger")
            db.session.rollback()
        elif guardar("Cliente actualizado.", "Ya existe un cliente con esa cédula/RUC."):
            return redirect(url_for("clientes"))
    return render_template("clientes/form.html", cliente=cliente, editando=True)


@app.route("/clientes/<int:id>/eliminar", methods=["POST"])
@login_required
def cliente_eliminar(id):
    cliente = db.get_or_404(Cliente, id)
    if cliente.facturas:
        flash("No se puede eliminar: el cliente tiene facturas registradas.", "danger")
    else:
        db.session.delete(cliente)
        guardar("Cliente eliminado.", "No se pudo eliminar el cliente.")
    return redirect(url_for("clientes"))


# ----------------------------------------------------------------- productos
def leer_producto(producto):
    """Valida el formulario de producto y asigna los valores. Devuelve errores."""
    producto.codigo = request.form.get("codigo", "").strip().upper()
    producto.nombre = request.form.get("nombre", "").strip()
    producto.descripcion = request.form.get("descripcion", "").strip()
    precio = a_decimal(request.form.get("precio"))
    stock = a_entero(request.form.get("stock"))
    producto.categoria_id = a_entero(request.form.get("categoria_id"))
    producto.proveedor_id = a_entero(request.form.get("proveedor_id"))

    errores = []
    if not producto.codigo or not producto.nombre:
        errores.append("El código y el nombre son obligatorios.")
    if precio is None or precio < 0:
        errores.append("Ingrese un precio válido (mayor o igual a 0).")
    else:
        producto.precio = precio
    if stock is None or stock < 0:
        errores.append("Ingrese un stock válido (entero mayor o igual a 0).")
    else:
        producto.stock = stock
    if not db.session.get(Categoria, producto.categoria_id or 0):
        errores.append("Seleccione una categoría.")
    if not db.session.get(Proveedor, producto.proveedor_id or 0):
        errores.append("Seleccione un proveedor.")
    return errores


def render_producto_form(producto, editando):
    return render_template("productos/form.html", producto=producto, editando=editando,
                           categorias=Categoria.query.order_by(Categoria.nombre).all(),
                           proveedores=Proveedor.query.order_by(Proveedor.nombre).all())


@app.route("/productos")
@login_required
def productos():
    q = request.args.get("q", "").strip()
    consulta = Producto.query
    if q:
        patron = f"%{q}%"
        consulta = consulta.filter(Producto.nombre.ilike(patron) | Producto.codigo.ilike(patron))
    return render_template("productos/lista.html", q=q,
                           productos=consulta.order_by(Producto.nombre).all())


@app.route("/productos/nuevo", methods=["GET", "POST"])
@login_required
def producto_nuevo():
    producto = Producto(stock=0)
    if request.method == "POST":
        errores = leer_producto(producto)
        if errores:
            for e in errores:
                flash(e, "danger")
        else:
            db.session.add(producto)
            if guardar("Producto creado.", "Ya existe un producto con ese código."):
                return redirect(url_for("productos"))
    return render_producto_form(producto, False)


@app.route("/productos/<int:id>/editar", methods=["GET", "POST"])
@login_required
def producto_editar(id):
    producto = db.get_or_404(Producto, id)
    if request.method == "POST":
        errores = leer_producto(producto)
        if errores:
            for e in errores:
                flash(e, "danger")
            db.session.rollback()
        elif guardar("Producto actualizado.", "Ya existe un producto con ese código."):
            return redirect(url_for("productos"))
    return render_producto_form(producto, True)


@app.route("/productos/<int:id>/eliminar", methods=["POST"])
@login_required
def producto_eliminar(id):
    producto = db.get_or_404(Producto, id)
    if producto.detalles:
        flash("No se puede eliminar: el producto aparece en facturas.", "danger")
    else:
        db.session.delete(producto)
        guardar("Producto eliminado.", "No se pudo eliminar el producto.")
    return redirect(url_for("productos"))


# ------------------------------------------------------------- facturación
@app.route("/facturas")
@login_required
def facturas():
    return render_template("facturas/lista.html",
                           facturas=Factura.query.order_by(Factura.fecha.desc()).all())


@app.route("/facturas/nueva", methods=["GET", "POST"])
@login_required
def factura_nueva():
    clientes_lista = Cliente.query.order_by(Cliente.nombre).all()
    productos_lista = Producto.query.filter(Producto.stock > 0).order_by(Producto.nombre).all()

    if request.method == "POST":
        cliente = db.session.get(Cliente, a_entero(request.form.get("cliente_id")) or 0)
        ids = request.form.getlist("producto_id")
        cantidades = request.form.getlist("cantidad")

        # Agrupa líneas repetidas del mismo producto
        pedido = {}
        for pid, cant in zip(ids, cantidades):
            pid, cant = a_entero(pid), a_entero(cant)
            if pid and cant and cant > 0:
                pedido[pid] = pedido.get(pid, 0) + cant

        errores = []
        if not cliente:
            errores.append("Seleccione un cliente.")
        if not pedido:
            errores.append("Agregue al menos un producto con cantidad válida.")

        lineas = []
        for pid, cant in pedido.items():
            producto = db.session.get(Producto, pid)
            if not producto:
                errores.append("Uno de los productos ya no existe.")
            elif cant > producto.stock:
                errores.append(f"Stock insuficiente de «{producto.nombre}» (disponible: {producto.stock}).")
            else:
                lineas.append((producto, cant))

        if errores:
            for e in errores:
                flash(e, "danger")
        else:
            factura = Factura(numero=f"TMP-{uuid4().hex[:12]}", cliente=cliente,
                              usuario_id=current_user.id,
                              observaciones=request.form.get("observaciones", "").strip())
            subtotal = Decimal("0")
            for producto, cant in lineas:
                factura.detalles.append(DetalleFactura(producto=producto, cantidad=cant,
                                                       precio_unitario=producto.precio))
                producto.stock -= cant
                subtotal += producto.precio * cant
            iva = (subtotal * Decimal(app.config["IVA_PORCENTAJE"]) / 100).quantize(Decimal("0.01"))
            factura.subtotal, factura.iva, factura.total = subtotal, iva, subtotal + iva
            db.session.add(factura)
            db.session.flush()  # obtiene el id para generar el número
            factura.numero = f"FAC-{factura.id:06d}"
            db.session.commit()
            flash(f"Factura {factura.numero} registrada.", "success")
            return redirect(url_for("factura_detalle", id=factura.id))

    return render_template("facturas/form.html", clientes=clientes_lista,
                           productos=productos_lista, iva=app.config["IVA_PORCENTAJE"])


@app.route("/facturas/<int:id>")
@login_required
def factura_detalle(id):
    return render_template("facturas/detalle.html", factura=db.get_or_404(Factura, id),
                           iva=app.config["IVA_PORCENTAJE"])


def devolver_stock(factura):
    for d in factura.detalles:
        d.producto.stock += d.cantidad


@app.route("/facturas/<int:id>/estado", methods=["POST"])
@login_required
def factura_estado(id):
    factura = db.get_or_404(Factura, id)
    nuevo = request.form.get("estado")
    if factura.estado == "anulada":
        flash("Una factura anulada no puede modificarse.", "danger")
    elif nuevo not in ("emitida", "pagada", "anulada"):
        flash("Estado no válido.", "danger")
    else:
        if nuevo == "anulada":
            devolver_stock(factura)
        factura.estado = nuevo
        guardar(f"Factura marcada como «{nuevo}».", "No se pudo actualizar la factura.")
    return redirect(url_for("factura_detalle", id=id))


@app.route("/facturas/<int:id>/eliminar", methods=["POST"])
@login_required
def factura_eliminar(id):
    factura = db.get_or_404(Factura, id)
    if factura.estado != "anulada":
        devolver_stock(factura)
    db.session.delete(factura)
    guardar("Factura eliminada.", "No se pudo eliminar la factura.")
    return redirect(url_for("facturas"))


# ------------------------------------------------------------------- errores
@app.errorhandler(404)
def no_encontrado(_):
    return render_template("404.html"), 404


if __name__ == "__main__":
    with app.app_context():
        db.create_all()  # crea las tablas si aún no existen
    app.run(debug=True)
