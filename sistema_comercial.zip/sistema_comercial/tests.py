"""Pruebas automáticas (SQLite en memoria). Ejecutar:  python -m unittest tests -v"""
import os
os.environ["DATABASE_URL"] = "sqlite:///:memory:"

import unittest
from app import app
from models import Factura, Producto, Usuario, db


class SistemaTests(unittest.TestCase):
    def setUp(self):
        app.config.update(TESTING=True, WTF_CSRF_ENABLED=False)
        self.ctx = app.app_context()
        self.ctx.push()
        db.drop_all()
        db.create_all()
        self.c = app.test_client()

    def tearDown(self):
        db.session.remove()
        self.ctx.pop()

    # ---- ayudas
    def registrar_y_entrar(self):
        self.c.post("/registro", data=dict(nombre="Ana Prueba", email="ana@test.com",
                                           password="secreto1", confirmar="secreto1"))
        return self.c.post("/login", data=dict(email="ana@test.com", password="secreto1"),
                           follow_redirects=True)

    def datos_base(self):
        self.c.post("/categorias/nueva", data=dict(nombre="Bebidas"))
        self.c.post("/proveedores/nuevo", data=dict(nombre="Prov", ruc="1791234567001"))
        self.c.post("/clientes/nuevo", data=dict(nombre="Cli", cedula="2100123456"))
        self.c.post("/productos/nuevo", data=dict(codigo="p1", nombre="Agua", precio="2.00",
                                                  stock="10", categoria_id="1", proveedor_id="1"))

    # ---- autenticación
    def test_rutas_protegidas_redirigen_a_login(self):
        for ruta in ["/dashboard", "/productos", "/clientes", "/proveedores", "/categorias", "/facturas"]:
            r = self.c.get(ruta)
            self.assertEqual(r.status_code, 302, ruta)
            self.assertIn("/login", r.headers["Location"], ruta)

    def test_password_se_guarda_con_hash(self):
        self.registrar_y_entrar()
        u = Usuario.query.filter_by(email="ana@test.com").one()
        self.assertNotEqual(u.password_hash, "secreto1")
        self.assertTrue(u.check_password("secreto1"))

    def test_login_incorrecto_y_correcto(self):
        self.c.post("/registro", data=dict(nombre="Ana Prueba", email="ana@test.com",
                                           password="secreto1", confirmar="secreto1"))
        r = self.c.post("/login", data=dict(email="ana@test.com", password="mala"))
        self.assertIn("incorrectos", r.get_data(as_text=True))
        r = self.c.post("/login", data=dict(email="ana@test.com", password="secreto1"),
                        follow_redirects=True)
        self.assertIn("Resumen del negocio", r.get_data(as_text=True))

    def test_registro_rechaza_email_duplicado(self):
        datos = dict(nombre="Ana Prueba", email="ana@test.com", password="secreto1", confirmar="secreto1")
        self.c.post("/registro", data=datos)
        r = self.c.post("/registro", data=datos)
        self.assertIn("Ya existe un usuario", r.get_data(as_text=True))
        self.assertEqual(Usuario.query.count(), 1)

    def test_logout_cierra_sesion(self):
        self.registrar_y_entrar()
        self.c.post("/logout")
        self.assertEqual(self.c.get("/productos").status_code, 302)

    def test_next_externo_es_ignorado(self):
        self.c.post("/registro", data=dict(nombre="Ana Prueba", email="ana@test.com",
                                           password="secreto1", confirmar="secreto1"))
        r = self.c.post("/login?next=https://malo.com", data=dict(email="ana@test.com", password="secreto1"))
        self.assertTrue(r.headers["Location"].endswith("/dashboard"))

    # ---- CRUD
    def test_crud_productos(self):
        self.registrar_y_entrar()
        self.datos_base()
        p = Producto.query.one()
        self.assertEqual(p.codigo, "P1")
        self.c.post(f"/productos/{p.id}/editar", data=dict(codigo="P1", nombre="Agua 1L", precio="2.50",
                                                           stock="8", categoria_id="1", proveedor_id="1"))
        self.assertEqual(db.session.get(Producto, p.id).nombre, "Agua 1L")
        self.assertIn("Agua 1L", self.c.get("/productos").get_data(as_text=True))
        self.c.post(f"/productos/{p.id}/eliminar")
        self.assertEqual(Producto.query.count(), 0)

    def test_no_elimina_categoria_con_productos(self):
        self.registrar_y_entrar()
        self.datos_base()
        self.c.post("/categorias/1/eliminar")
        self.assertIn("Bebidas", self.c.get("/categorias").get_data(as_text=True))

    def test_validaciones_de_producto(self):
        self.registrar_y_entrar()
        self.datos_base()
        self.c.post("/productos/nuevo", data=dict(codigo="p2", nombre="X", precio="-1",
                                                  stock="abc", categoria_id="1", proveedor_id="1"))
        self.assertEqual(Producto.query.count(), 1)

    # ---- facturación
    def test_factura_descuenta_stock_y_calcula_totales(self):
        self.registrar_y_entrar()
        self.datos_base()
        self.c.post("/facturas/nueva", data={"cliente_id": "1", "producto_id": ["1"], "cantidad": ["3"]})
        f = Factura.query.one()
        self.assertEqual(f.numero, "FAC-000001")
        self.assertEqual(float(f.subtotal), 6.00)
        self.assertEqual(float(f.iva), 0.90)
        self.assertEqual(float(f.total), 6.90)
        self.assertEqual(db.session.get(Producto, 1).stock, 7)

    def test_factura_rechaza_stock_insuficiente(self):
        self.registrar_y_entrar()
        self.datos_base()
        self.c.post("/facturas/nueva", data={"cliente_id": "1", "producto_id": ["1"], "cantidad": ["99"]})
        self.assertEqual(Factura.query.count(), 0)
        self.assertEqual(db.session.get(Producto, 1).stock, 10)

    def test_anular_y_eliminar_factura_devuelven_stock(self):
        self.registrar_y_entrar()
        self.datos_base()
        self.c.post("/facturas/nueva", data={"cliente_id": "1", "producto_id": ["1"], "cantidad": ["4"]})
        self.c.post("/facturas/1/estado", data={"estado": "anulada"})
        self.assertEqual(db.session.get(Producto, 1).stock, 10)
        self.c.post("/facturas/1/eliminar")  # ya anulada: no debe devolver dos veces
        self.assertEqual(db.session.get(Producto, 1).stock, 10)
        self.assertEqual(Factura.query.count(), 0)


if __name__ == "__main__":
    unittest.main()
