import os

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:  # python-dotenv es opcional
    pass


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "clave-solo-para-desarrollo")
    # Por defecto MySQL. Para PostgreSQL cambie DATABASE_URL en el archivo .env
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL",
        "mysql+pymysql://root:@localhost:3306/sistema_comercial",
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    IVA_PORCENTAJE = 15  # Ajuste según la tarifa vigente
