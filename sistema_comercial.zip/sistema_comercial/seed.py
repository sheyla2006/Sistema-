"""Carga datos de ejemplo. Uso:  python seed.py
Usuario de prueba: admin@demo.com / Admin123"""
from app import app
from models import Categoria, Cliente, Producto, Proveedor, Usuario, db

with app.app_context():
    db.create_all()
    if Usuario.query.first():
        print("La base de datos ya tiene datos; no se cargó nada.")
        raise SystemExit

    admin = Usuario(nombre="Administrador", email="admin@demo.com")
    admin.set_password("Admin123")

    cats = [Categoria(nombre=n, descripcion=d) for n, d in [
        ("Bebidas", "Jugos, agua y gaseosas"),
        ("Abarrotes", "Productos de despensa"),
        ("Limpieza", "Artículos de aseo")]]
    provs = [
        Proveedor(nombre="Distribuidora Amazonía S.A.", ruc="1791234567001", telefono="062830000", email="ventas@amazonia.ec", direccion="Lago Agrio"),
        Proveedor(nombre="Alimentos del Oriente Cía. Ltda.", ruc="1792345678001", telefono="062840000", email="info@oriente.ec", direccion="Shushufindi"),
    ]
    clientes = [
        Cliente(nombre="María Torres", cedula="2100123456", telefono="0991112233", email="maria@correo.com", direccion="Shushufindi"),
        Cliente(nombre="Comercial El Ahorro", cedula="2190001234001", telefono="0984445566", email="ahorro@correo.com", direccion="Lago Agrio"),
    ]
    db.session.add_all([admin, *cats, *provs, *clientes])
    db.session.flush()

    db.session.add_all([
        Producto(codigo="BEB-001", nombre="Agua 600 ml", precio=0.60, stock=120, categoria_id=cats[0].id, proveedor_id=provs[0].id),
        Producto(codigo="BEB-002", nombre="Jugo de naranja 1 L", precio=1.75, stock=40, categoria_id=cats[0].id, proveedor_id=provs[0].id),
        Producto(codigo="ABA-001", nombre="Arroz 1 kg", precio=1.10, stock=80, categoria_id=cats[1].id, proveedor_id=provs[1].id),
        Producto(codigo="ABA-002", nombre="Aceite 1 L", precio=3.20, stock=4, categoria_id=cats[1].id, proveedor_id=provs[1].id),
        Producto(codigo="LIM-001", nombre="Detergente 2 kg", precio=5.90, stock=25, categoria_id=cats[2].id, proveedor_id=provs[0].id),
    ])
    db.session.commit()
    print("Datos de ejemplo cargados. Usuario: admin@demo.com  Clave: Admin123")
